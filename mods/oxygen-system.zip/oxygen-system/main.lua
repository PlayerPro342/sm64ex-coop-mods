-- name: Oxygen System
-- description: Adds an oxygen system, like newer Mario games.\nSome options can be changed with commands.\n\n\\#808080\\(Author: devmario, Helper: Troopa)
-- incompatible: oxygen

E_MODEL_AIRTANK = smlua_model_util_get_id("air_tank_geo")