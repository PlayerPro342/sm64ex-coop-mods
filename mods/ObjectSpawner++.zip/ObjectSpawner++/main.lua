-- name: Object Spawner++
-- description: Object Spawner++\nBy \\#6666ff\\dev\\#0000ff\\mario\n\n\\#dcdcdc\\A modified version of Object Spawner V2.1, with new and neat additions!

_G.objspawnerExists = true